﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gdelbridDungeon.Entities;  

namespace gdelbridDungeon.Core
{
    public static class BaseSkills
    {
        public static Skill AttackSkill(DamageType damageType, Func<int> getAttackValue) =>
            new Skill(targets => targets.First().AssignDamage(getAttackValue.Invoke(), damageType))
            {
                DisplayMessage = "{SELF} attacks {TARGET} for {AMOUNT} damage!",
                TargetingType = TargetingType.OneEnemy,
            };
    }
}
