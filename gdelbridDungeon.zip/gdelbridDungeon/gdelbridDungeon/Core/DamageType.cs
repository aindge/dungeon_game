﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gdelbridDungeon.Entities;

namespace gdelbridDungeon.Core
{
    public enum DamageType
    {
        Physical, Magical
    }
}
