﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gdelbridDungeon.Entities
{
    public class ExportedGameState
    {
        public string Enemy1Name { get; set; }
        public int Enemy1CurrentHealth { get; set; }
        public int Ally1CurrentHealth { get; set; }
        public string Ally1Name { get; set; }
        public List<string> DisplayMessages { get; set; }
    }
}
