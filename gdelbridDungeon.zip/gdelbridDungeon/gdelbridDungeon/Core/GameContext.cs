﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gdelbridDungeon.Entities;

namespace gdelbridDungeon.Core
{
    public class GameContext : IGameContext
    {

        public GameContext()
        {
            var cleric = new Cleric(this);
            var bandit = new Bandit(this);

            _turnList = new InitiativeList();

            Allies.Add(cleric);
            Enemies.Add(bandit);
            AllActors.OrderByDescending(x => x.Speed).ToList().ForEach(a => _turnList.Add(a));

            DisplayMessages = new List<string>();

            // Add stuff to turn list here
        }
       
        private readonly InitiativeList _turnList;
        public List<Entity> Allies { get; set; } = new List<Entity>();
        public List<Entity> Enemies { get; set; } = new List<Entity>();
        public List<Entity> AllActors => Allies.Union(Enemies).ToList();

        public List<string> DisplayMessages { get; set; }
        List<Entity> IGameContext.AllActors { get; set; }
        List<string> IGameContext.DisplayMessages { get; set; }

            
        public ExportedGameState ExportGameState()
        {
            return new ExportedGameState()
            {
                Enemy1Name = Enemies[0].Name,
                Enemy1CurrentHealth = Enemies[0].CurrentHealth,
                Ally1Name = Allies[0].Name,
                Ally1CurrentHealth = Allies[0].CurrentHealth,
                DisplayMessages = DisplayMessages.ToList(), // Clone list
   
            };
        }

        public void ApplyActions()
        {
            var currentEntity = _turnList[_turnList.CurrentPosition];
            // Do stuff with current actor here...

            while (true)
            {
                currentEntity = _turnList.Next();
                if (currentEntity is Player)
                {
                    break;
                }
                var enemy = currentEntity as Enemies;
                if (enemy is null)
                {
                    throw new InvalidOperationException("This should not happen!");
                }
                enemy.Act();
            }
        }
    }
}
