﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gdelbridDungeon.Entities;

namespace gdelbridDungeon.Core
{
    public interface IGameContext
    {
        List<Entity> Allies { get; set; }
        List<Entity> Enemies { get; set; }
        List<Entity> AllActors { get; set; }
        List<string> DisplayMessages { get; set; }
        ExportedGameState ExportGameState();
    }
}
