﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using gdelbridDungeon.Core;
using gdelbridDungeon.Entities;


namespace gdelbridDungeon.Core
{
    public class InitiativeList : IList<Entity>
    {
        private readonly List<Entity> _orderedTurnList = new List<Entity>();
        public int CurrentPosition { get; set; }
        public Entity Next()
        {
            var result = _orderedTurnList[CurrentPosition];

            CurrentPosition = CurrentPosition >= _orderedTurnList.Count - 1 ? 0 : CurrentPosition + 1;

            return result;
        }

        public IEnumerator<Entity> GetEnumerator()
        {
            return _orderedTurnList.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable)_orderedTurnList).GetEnumerator();
        }

        public void Add(Entity item)
        {
            _orderedTurnList.Add(item);
        }

        public void Clear()
        {
            _orderedTurnList.Clear();
        }

        public bool Contains(Entity item)
        {
            return _orderedTurnList.Contains(item);
        }

        public void CopyTo(Entity[] array, int arrayIndex)
        {
            _orderedTurnList.CopyTo(array, arrayIndex);
        }

        public bool Remove(Entity item)
        {
            return _orderedTurnList.Remove(item);
        }

        public int Count
        {
            get { return _orderedTurnList.Count; }
        }

        public bool IsReadOnly
        {
            get { return ((ICollection<Entity>)_orderedTurnList).IsReadOnly; }
        }

        public int IndexOf(Entity item)
        {
            return _orderedTurnList.IndexOf(item);
        }

        public void Insert(int index, Entity item)
        {
            _orderedTurnList.Insert(index, item);
        }

        public void RemoveAt(int index)
        {
            _orderedTurnList.RemoveAt(index);
        }

        public Entity this[int index]
        {
            get { return _orderedTurnList[index]; }
            set { _orderedTurnList[index] = value; }
        }
    }
}
