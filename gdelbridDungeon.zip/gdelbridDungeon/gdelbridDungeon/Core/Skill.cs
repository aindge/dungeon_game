﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gdelbridDungeon.Entities;

namespace gdelbridDungeon.Core
{
    public class Skill
    {
        public Skill(Func<List<Entity>, int> func)
        {
            _skillFunction = func;
        }

        private readonly Func<List<Entity>, int> _skillFunction;
        public TargetingType TargetingType { get; set; }
        public string DisplayMessage { get; set; }
        public int ManaCost { get; set; }

        public string FormatDisplayMessage(Entity self, Entity target, int amount)
        {
            return DisplayMessage.Replace("{SELF}", self.Name)
                                 .Replace("{TARGET}", target?.Name ?? string.Empty)
                                 .Replace("{AMOUNT}", amount.ToString());
        }

        public int Invoke(List<Entity> entity)
        {
            return _skillFunction.Invoke(entity);
        }
    }
}
