﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gdelbridDungeon.Entities;

namespace gdelbridDungeon.Core
{
    public enum TargetingType
    {
        Self,
        OneAlly,
        OneOtherAlly,
        OneEnemy,
        AllAllies,
        AllEnemies,
        Everyone,
    }
}
