﻿using System;

namespace gdelbridDungeon
{
    partial class Dungeon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dungeon));
            this.GamePanel = new System.Windows.Forms.Panel();
            this.CombatTextbox = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Enemy3Button = new System.Windows.Forms.Button();
            this.Enemy2Button = new System.Windows.Forms.Button();
            this.Enemy1Button = new System.Windows.Forms.Button();
            this.ActionPanel = new System.Windows.Forms.Panel();
            this.SpecialButton = new System.Windows.Forms.Button();
            this.DefButton = new System.Windows.Forms.Button();
            this.AttackButton = new System.Windows.Forms.Button();
            this.DungeonBackground = new System.Windows.Forms.PictureBox();
            this.ClericLabel = new System.Windows.Forms.Label();
            this.EnemyOneLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.EnemyOneHp = new System.Windows.Forms.Label();
            this.GamePanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.ActionPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DungeonBackground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // GamePanel
            // 
            this.GamePanel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.GamePanel.Controls.Add(this.CombatTextbox);
            this.GamePanel.Controls.Add(this.panel1);
            this.GamePanel.Controls.Add(this.ActionPanel);
            this.GamePanel.Location = new System.Drawing.Point(-1, 436);
            this.GamePanel.Name = "GamePanel";
            this.GamePanel.Size = new System.Drawing.Size(1118, 312);
            this.GamePanel.TabIndex = 0;
            // 
            // CombatTextbox
            // 
            this.CombatTextbox.Location = new System.Drawing.Point(542, 28);
            this.CombatTextbox.Multiline = true;
            this.CombatTextbox.Name = "CombatTextbox";
            this.CombatTextbox.ReadOnly = true;
            this.CombatTextbox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.CombatTextbox.Size = new System.Drawing.Size(529, 265);
            this.CombatTextbox.TabIndex = 1;
            this.CombatTextbox.TextChanged += new System.EventHandler(this.CombatTextbox_TextChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Menu;
            this.panel1.Controls.Add(this.Enemy3Button);
            this.panel1.Controls.Add(this.Enemy2Button);
            this.panel1.Controls.Add(this.Enemy1Button);
            this.panel1.Location = new System.Drawing.Point(294, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(224, 265);
            this.panel1.TabIndex = 4;
            // 
            // Enemy3Button
            // 
            this.Enemy3Button.Location = new System.Drawing.Point(38, 183);
            this.Enemy3Button.Name = "Enemy3Button";
            this.Enemy3Button.Size = new System.Drawing.Size(157, 59);
            this.Enemy3Button.TabIndex = 3;
            this.Enemy3Button.Text = "Enemy Three";
            this.Enemy3Button.UseVisualStyleBackColor = true;
            // 
            // Enemy2Button
            // 
            this.Enemy2Button.Location = new System.Drawing.Point(38, 106);
            this.Enemy2Button.Name = "Enemy2Button";
            this.Enemy2Button.Size = new System.Drawing.Size(157, 59);
            this.Enemy2Button.TabIndex = 2;
            this.Enemy2Button.Text = "Enemy Two";
            this.Enemy2Button.UseVisualStyleBackColor = true;
            // 
            // Enemy1Button
            // 
            this.Enemy1Button.Location = new System.Drawing.Point(38, 30);
            this.Enemy1Button.Name = "Enemy1Button";
            this.Enemy1Button.Size = new System.Drawing.Size(157, 59);
            this.Enemy1Button.TabIndex = 1;
            this.Enemy1Button.Text = "Enemy One";
            this.Enemy1Button.UseVisualStyleBackColor = true;
            this.Enemy1Button.Click += new System.EventHandler(this.Enemy1Button_Click);
            // 
            // ActionPanel
            // 
            this.ActionPanel.BackColor = System.Drawing.SystemColors.Menu;
            this.ActionPanel.Controls.Add(this.SpecialButton);
            this.ActionPanel.Controls.Add(this.DefButton);
            this.ActionPanel.Controls.Add(this.AttackButton);
            this.ActionPanel.Location = new System.Drawing.Point(30, 28);
            this.ActionPanel.Name = "ActionPanel";
            this.ActionPanel.Size = new System.Drawing.Size(224, 265);
            this.ActionPanel.TabIndex = 1;
            // 
            // SpecialButton
            // 
            this.SpecialButton.Location = new System.Drawing.Point(31, 183);
            this.SpecialButton.Name = "SpecialButton";
            this.SpecialButton.Size = new System.Drawing.Size(157, 59);
            this.SpecialButton.TabIndex = 3;
            this.SpecialButton.Text = "Special";
            this.SpecialButton.UseVisualStyleBackColor = true;
            // 
            // DefButton
            // 
            this.DefButton.Location = new System.Drawing.Point(31, 106);
            this.DefButton.Name = "DefButton";
            this.DefButton.Size = new System.Drawing.Size(157, 59);
            this.DefButton.TabIndex = 2;
            this.DefButton.Text = "Defend";
            this.DefButton.UseVisualStyleBackColor = true;
            this.DefButton.Click += new System.EventHandler(this.DefButton_Click);
            // 
            // AttackButton
            // 
            this.AttackButton.Location = new System.Drawing.Point(31, 30);
            this.AttackButton.Name = "AttackButton";
            this.AttackButton.Size = new System.Drawing.Size(157, 59);
            this.AttackButton.TabIndex = 1;
            this.AttackButton.Text = "Attack";
            this.AttackButton.UseVisualStyleBackColor = true;
            this.AttackButton.Click += new System.EventHandler(this.AttackButton_Click);
            // 
            // DungeonBackground
            // 
            this.DungeonBackground.Image = ((System.Drawing.Image)(resources.GetObject("DungeonBackground.Image")));
            this.DungeonBackground.Location = new System.Drawing.Point(-1, -4);
            this.DungeonBackground.Name = "DungeonBackground";
            this.DungeonBackground.Size = new System.Drawing.Size(1118, 444);
            this.DungeonBackground.TabIndex = 5;
            this.DungeonBackground.TabStop = false;
            this.DungeonBackground.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // ClericLabel
            // 
            this.ClericLabel.AutoSize = true;
            this.ClericLabel.Location = new System.Drawing.Point(642, 94);
            this.ClericLabel.Name = "ClericLabel";
            this.ClericLabel.Size = new System.Drawing.Size(67, 25);
            this.ClericLabel.TabIndex = 6;
            this.ClericLabel.Text = "Cleric";
            // 
            // EnemyOneLabel
            // 
            this.EnemyOneLabel.AutoSize = true;
            this.EnemyOneLabel.Location = new System.Drawing.Point(12, 94);
            this.EnemyOneLabel.Name = "EnemyOneLabel";
            this.EnemyOneLabel.Size = new System.Drawing.Size(124, 25);
            this.EnemyOneLabel.TabIndex = 7;
            this.EnemyOneLabel.Text = "Enemy One";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(630, 140);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(93, 87);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Location = new System.Drawing.Point(75, 140);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(109, 88);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // EnemyOneHp
            // 
            this.EnemyOneHp.AutoSize = true;
            this.EnemyOneHp.Location = new System.Drawing.Point(161, 94);
            this.EnemyOneHp.Name = "EnemyOneHp";
            this.EnemyOneHp.Size = new System.Drawing.Size(125, 25);
            this.EnemyOneHp.TabIndex = 10;
            this.EnemyOneHp.Text = "Click for HP";
            this.EnemyOneHp.Click += new System.EventHandler(this.EnemyOneHp_Click);
            // 
            // Dungeon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1114, 746);
            this.Controls.Add(this.EnemyOneHp);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.EnemyOneLabel);
            this.Controls.Add(this.ClericLabel);
            this.Controls.Add(this.DungeonBackground);
            this.Controls.Add(this.GamePanel);
            this.Name = "Dungeon";
            this.Text = "Dungeon";
            this.Load += new System.EventHandler(this.Dungeon_Load);
            this.GamePanel.ResumeLayout(false);
            this.GamePanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ActionPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DungeonBackground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        #endregion

        private System.Windows.Forms.Panel GamePanel;
        private System.Windows.Forms.Panel ActionPanel;
        private System.Windows.Forms.Button SpecialButton;
        private System.Windows.Forms.Button DefButton;
        private System.Windows.Forms.Button AttackButton;
        private System.Windows.Forms.TextBox CombatTextbox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Enemy3Button;
        private System.Windows.Forms.Button Enemy2Button;
        private System.Windows.Forms.Button Enemy1Button;
        private System.Windows.Forms.PictureBox DungeonBackground;
        private System.Windows.Forms.Label ClericLabel;
        private System.Windows.Forms.Label EnemyOneLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label EnemyOneHp;
    }
}

