﻿using gdelbridDungeon.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using gdelbridDungeon.Core;

namespace gdelbridDungeon
{
    public partial class Dungeon : Form
    {
        
        GameContext game = new GameContext();

        public Dungeon()
        { 
            InitializeComponent();
        }
 
        public void UpdateGame()
        {
            game.ApplyActions();
            CombatTextbox.Text = string.Join("\n", game.DisplayMessages);
        }

        
        private void Dungeon_Load(object sender, EventArgs e)
        {
            
        }

        private void AttackButton_Click(object sender, EventArgs e)
        {
            UpdateGame();
        }

        private void CombatTextbox_TextChanged(object sender, EventArgs e)
        {

            
        }

        private void DefButton_Click(object sender, EventArgs e)
        {
                
        }

        private void Enemy1Button_Click(object sender, EventArgs e)
        {
            UpdateGame();
        }

        private void EnemyOneHp_Click(object sender, EventArgs e)
        {
            Bandit bandit = new Bandit(game);
            EnemyOneHp.Text = bandit.CurrentHealth.ToString();
        }
    }
}
