﻿using gdelbridDungeon.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using gdelbridDungeon.Core;

namespace gdelbridDungeon.Entities
{
    class Bandit : Enemies
    {
        public Bandit(IGameContext context) : base(context)
        {
            Strength = 6;
            Intelligence = 2;
            PhysicalDefense = 4;
            MagicDefense = 4;
            Speed = 8;
            InitMana(20);
            InitHealth(10);
        }

        public override void InitSkills()
        {
            SkillSet.Add("Attack", BaseSkills.AttackSkill(DamageType.Physical, () => Strength));
        }
    }
}
