﻿using gdelbridDungeon.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gdelbridDungeon.Entities
{
    public abstract class Enemies : Entity
    {
        public virtual void Act()
        {
            var rand = new Random();
            var isValidCommand = false;
            KeyValuePair<string, Skill> skillChoice = new KeyValuePair<string, Skill>();
            var targets = new List<Entity>();
            while (!isValidCommand)
            {
                skillChoice = SkillSet.ToList()[rand.Next(SkillSet.Count)];

                switch (skillChoice.Value.TargetingType)
                {
                    case TargetingType.Self:
                        targets.Add(this);
                        break;
                    case TargetingType.OneAlly:
                        targets.Add(Context.Enemies[rand.Next(Context.Enemies.Count)]);
                        break;
                    case TargetingType.OneOtherAlly:
                        if (Context.Enemies.Count == 1)
                        {
                            continue;
                        }
                        Entity target = this;
                        while (target == this)
                            target = Context.Enemies[rand.Next(Context.Enemies.Count)];
                        targets.Add(target);
                        break;
                    case TargetingType.OneEnemy:
                        targets.Add(Context.Allies[rand.Next(Context.Allies.Count)]);
                        break;
                    case TargetingType.AllAllies:
                        targets.AddRange(Context.Enemies);
                        break;
                    case TargetingType.AllEnemies:
                        targets.AddRange(Context.Allies);
                        break;
                    case TargetingType.Everyone:
                        targets.AddRange(Context.AllActors);
                        break;
                    default:
                        throw new ArgumentOutOfRangeException();
                }
                isValidCommand = true;
            }
            UseSkill(skillChoice.Key, targets);
        }

        public Enemies(IGameContext context) : base(context)
        {
            
        }

        public override void InitSkills()
        {
            throw new System.NotImplementedException();
        }
    }
}
