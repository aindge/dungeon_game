﻿using gdelbridDungeon.Core;
using System;
using System.Collections.Generic;
using System.Linq;


namespace gdelbridDungeon.Entities
{

    /// <summary>
    /// This class creates a basic "Entity" that will form the basis of each and every 
    /// creature in the game.
    /// </summary>
    public abstract class Entity
    {
        protected readonly IGameContext Context;

        protected Entity(IGameContext context)
        {
            Context = context;
            SkillSet = new Dictionary<string, Skill>();
            InitSkills();
        }

        protected Dictionary<string, Skill> SkillSet { get; set; }

        #region Properties Region

        //Getters and setters for each property.
        public string Name { get; private set; }       
        public int Strength { get; protected set; }
        public int Intelligence { get; protected set; }
        public int MaxHealth { get; protected set; }
        public int CurrentHealth { get; set; }
        public int MaxSkillPoints { get; protected set; }
        public int CurrentSkillPoints { get; protected set; }
        public int PhysicalDefense { get; protected set; }
        public int MagicDefense { get; protected set; }
        public int Speed { get; protected set; }

        #endregion

        public abstract void InitSkills();

        public int UseSkill(string command, List<Entity> target)
        {
            var skill = SkillSet[command];
            if (skill is null)
            {
                throw new InvalidOperationException("Ouch");
            }
            CurrentSkillPoints -= skill.ManaCost;

            var amount = skill.Invoke(target);
            var displayMessage = skill.FormatDisplayMessage(this, target.FirstOrDefault(), amount);

            Context.DisplayMessages.Add(displayMessage);

            return amount;
        }

        protected void InitHealth(int amount)
        {
            MaxHealth = amount;
            CurrentHealth = amount;
        }

        protected void InitMana(int amount)
        {
            CurrentSkillPoints = amount;
            MaxSkillPoints = amount;
        }

        public int AssignDamage(int baseAttack, DamageType damageType)
        {
            var damageDealt = 0;
            switch (damageType)
            {
                case DamageType.Physical:
                    damageDealt = baseAttack - PhysicalDefense;
                    break;
                case DamageType.Magical:
                    damageDealt = baseAttack - MagicDefense;
                    break;
            }
            CurrentHealth -= damageDealt;
            return damageDealt;
        }

    }
}