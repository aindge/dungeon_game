﻿using System;
using gdelbridDungeon.Core;

namespace gdelbridDungeon.Entities
{
    public abstract class Player : Entity
    {
        protected Player(IGameContext context) : base(context)
        {

        }
    }
}
